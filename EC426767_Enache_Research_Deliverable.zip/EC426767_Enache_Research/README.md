# EC-426767 | Occupational Workforce-Cost Analysis

Enache Ionuț-Alexandru | Weeks 01-04 | Issue date: 25 November 2026

## Deliverables

week1/: Parameter Specification, variable register and initial ranges.  
week2/: Parameter Register.  
week3/: Scenario Analysis.  
week4/: Results Report, Executive Summary and Publication Tables.  
figures/: Four publication figures in PDF/SVG/PNG with captions.  
parameters/: 528 classified records, scenario design, input derivations and the six-field application-input table.  
results/: Original application annual exports and aggregated research tables.  
ECorp/: The supplied application source and 88 executable configurations under config/enache/.  
references/: Source evidence, source register and software snapshot.  
verification/: Application hashes, numerical checks, execution records and archive checksums.

## Application inputs

Each file in ECorp/config/enache/S0/, S1/, S2/ or S3/ is a JSON object containing exactly:

    employees
    replaced
    annual_employee_cost
    annual_ai_cost
    implementation_cost
    years

Each scenario has 22 occupational configurations. The original group employment is retained. These represent occupational cohorts, not an invented company. The four scenario totals are sums of 22 separate application runs; they are not a single homogeneous-workforce run.

Costs are RON. annual_employee_cost is annual cost per employee; annual_ai_cost is the total recurring AI budget; implementation_cost is a total one-time initial integration/training budget. replaced is an integer initial count, fixed throughout the projection. years is 5. Source/classification metadata is kept outside executable JSON because the application rejects extra fields.

Run one configuration from the package root:

    python ECorp/src/week2.py --parameters ECorp/config/enache/S2/EC426767_S2_SOC43.json --output results/EC426767_S2_SOC43.csv

This is the application's supplied JSON loader and CSV exporter. The example above uses Office and Administrative Support. The full input table is parameters/application_inputs.csv; parameters/config_index.csv lists all 88 paths.

## Reproduce all research outputs

Python 3.10+, standard library for numerical execution:

    python analysis/run_all.py

This prepares 88 configurations, executes the original application CLI 88 times, evaluates 352 sensitivity cases through its original projection function, and runs verification. All ten original software files are checked by hash. Inputs and results are written within this package. No default hypothetical configuration is used for the research results.

Optional PDF/SVG publication rebuild:

    python -m pip install -r analysis/requirements.txt
    python analysis/run_all.py --reports

To also regenerate PNG figures, install Poppler with pdftoppm on PATH, then:

    python analysis/run_all.py --reports --png

Supplied publication PDFs, SVGs and PNGs are already available. The application itself needs no extra packages for the CLI. Its optional Streamlit interface requires streamlit, pandas and plotly, as described in ECorp/README.md.

## Dashboard use

The dashboard uses the same original project_costs function. Enter one row from parameters/application_inputs.csv into its six controls. Use total costs, not per-user prices, and set the horizon to 5 years. The supplied dashboard has manual controls; JSON import and CSV export are available through src/week2.py, not a dashboard upload/download button. Aggregated scenario results are produced by analysis/run_scenarios.py.

## Parameter basis

The population is 161,931,500 jobs in 785 U.S. occupations, aggregated into 22 groups. Annual employee cost uses the known-wage weighted occupation median proxy, reported 1.43 loading and 4.6885 RON/USD. The latter is the 2022 annual average published by BNR (R05, printed p. 68, table 13.1). Currency conversion does not turn U.S. wages into Romanian wages.

Deployment, initial replacement targets, redeployment and AI budgets are assumptions. Task time saved and exposure are transferred/derived estimates. Initial replacement is floored and bounded by group spare capacity. The one-time integration reserve per planned AI user is assumed equal to one annual license fee; training is added once per initially replaced employee. These are separate initial budget components, not an annual per-user implementation charge entered as a project total.

The original application calculates constant-workforce cost projections. It does not calculate exposure, replacement feasibility, demand or training separately; these are documented input-preparation relationships. It charges the prepared implementation total only in year 1. Later annual savings remain constant. No annual replacement accumulation, hidden capacity mechanism or alternative financial model is used in the projection.

## Sources and interpretation

R01-R03 document the occupational evidence and parameter ranges. R04 is contextual prior reference analysis; current results are generated by the supplied ECorp application S01. Source authorship is preserved in the Source Register. The software snapshot contains the unchanged files from the previously verified archive extraction; source-file hashes identify the application version.

All outputs are modeled workforce-cost savings, not company profit, measured layoffs or an optimal staffing decision. Revenue, quality, severance, discounting and the output value of redeployed time are not modeled. The wage base, reported cost proxies and fixed currency basis form an analytical budget scenario, not a current-price national forecast.

Verification covers all 88 JSON loads, original CLI CSV exports, independent decimal cost identities, source/software integrity, aggregation, sensitivity, publication values and reproducibility after a fresh archive extraction.
