"""Build Enache's Week4 English report, paper tables and publication figures.
All plotted/published values come from the saved-output analysis tables.
"""
from pathlib import Path
import csv,json,math,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.graphics.shapes import Drawing,Rect,String,Line,Circle
from reportlab.graphics import renderPDF,renderSVG
ROOT=Path(__file__).resolve().parents[1];W4=ROOT
FONT='Helvetica';BOLD='Helvetica-Bold'
if Path('C:/Windows/Fonts/arial.ttf').exists():
 pdfmetrics.registerFont(TTFont('W4Body','C:/Windows/Fonts/arial.ttf'));pdfmetrics.registerFont(TTFont('W4Bold','C:/Windows/Fonts/arialbd.ttf'));FONT='W4Body';BOLD='W4Bold'
C=colors.HexColor;INK=C('#16364a');BLUE=C('#237f91');GOLD=C('#cf8a42');GRAY=C('#526676');RED=C('#b45451')
styles=getSampleStyleSheet()
for name,font,size,leading,color,space in [('W4Title',BOLD,22,27,INK,12),('W4H',BOLD,12,16,INK,7),('W4Body',FONT,9.5,13.5,INK,8),('W4Small',FONT,8,11,GRAY,6),('W4Cell',FONT,7.5,10,INK,0)]:
 styles.add(ParagraphStyle(name=name,fontName=font,fontSize=size,leading=leading,textColor=color,spaceAfter=space,spaceBefore=7 if name=='W4H' else 0))
def p(t,style='W4Body'):return Paragraph(html.escape(str(t)),styles[style])
def read(name):
 with (W4/'tables'/name).open(encoding='utf-8') as f:return list(csv.DictReader(f))
def n(v,d=2):return f'{float(v):,.{d}f}'
def table(headers,rows,widths):
 t=Table([[p(x,'W4Cell') for x in headers]]+[[p(x,'W4Cell') for x in r] for r in rows],colWidths=widths,repeatRows=1,hAlign='LEFT')
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),C('#deebf0')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,C('#f1f5f7')]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('LINEBELOW',(0,0),(-1,0),.8,C('#8aa0ac'))]))
 return t
def footer(c,doc):
 c.setStrokeColor(C('#c1d0d9'));c.line(42,36,553,36);c.setFont(FONT,8);c.setFillColor(GRAY)
 c.drawString(42,23,'Enache Ionuț-Alexandru | EC-426767 | Research | 25 November 2026');c.drawRightString(553,23,str(doc.page))
def pdf(path,story,title):
 def maker(*args,**kwargs):kwargs['invariant']=1;return canvas.Canvas(*args,**kwargs)
 SimpleDocTemplate(str(path),pagesize=(595.28,841.89),leftMargin=42,rightMargin=42,topMargin=40,bottomMargin=48,title=title,author='Enache Ionuț-Alexandru').build(story,onFirstPage=footer,onLaterPages=footer,canvasmaker=maker)
def txt(d,x,y,t,size=10,bold=False,color=INK):d.add(String(x,y,str(t),fontName=BOLD if bold else FONT,fontSize=size,fillColor=color))
def fig_header(d,title,sub):txt(d,24,d.height-30,title,17,True);txt(d,24,d.height-50,sub,9,color=GRAY)
def save_figure(name,d):
 target=W4/'figures'/name
 c=canvas.Canvas(str(target.with_suffix('.pdf')),pagesize=(d.width,d.height),invariant=1);c.setTitle(name);c.setAuthor('Enache Ionuț-Alexandru');renderPDF.draw(d,c,0,0);c.showPage();c.save()
 target.with_suffix('.svg').write_text(renderSVG.drawToString(d),encoding='utf-8')
def scaled(d,width=500):
 factor=width/d.width;clone=Drawing(width,d.height*factor);clone.add(d);clone.scale(factor,factor);return clone
