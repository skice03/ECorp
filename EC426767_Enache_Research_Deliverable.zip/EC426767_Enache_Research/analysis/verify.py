"""Verify parameters, original application executions and exported outputs."""
from pathlib import Path
from decimal import Decimal
import csv,json,math,hashlib,subprocess,sys
from prepare_parameters import load,aggregate_groups,application_input,read,FIELDS
ROOT=Path(__file__).resolve().parents[1];APP=ROOT/'ECorp';sys.path.insert(0,str(APP))
from src.week2 import load_parameters,run_projection,RESULT_COLUMNS
def main():
 checks=[];reconciliations=[]
 def check(name,condition):
  checks.append(dict(check=name,status='PASS' if condition else 'FAIL'))
  if not condition:raise AssertionError(name)
 def close(a,b):return abs(float(a)-float(b))<=max(.05,8*math.ulp(max(abs(float(a)),abs(float(b)),1.0)))
 settings,scenarios,occupations=load();groups=aggregate_groups(occupations,settings);bygroup={g['soc_major']:g for g in groups};byscenario={s['id']:s for s in scenarios}
 check('785 original occupation rows, no duplicate SOC keys',len(occupations)==len({r['soc'] for r in occupations})==785)
 check('Original 161931500 jobs across22 occupational groups',len(groups)==22 and sum(g['employees'] for g in groups)==161931500)
 check('16 missing occupation wages remain missing',sum(r['wage_2022_usd'] is None for r in occupations)==16)
 check('Recorded currency basis is 4.6885 RON/USD, 2022',settings['usd_to_ron']==4.6885 and settings['exchange_period']==2022 and settings['currency']=='RON')
 sources=json.loads((ROOT/'verification/source_manifest.json').read_text());software=json.loads((ROOT/'verification/application_manifest.json').read_text())
 sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
 check('All archived reference files unchanged',all(sha(ROOT/r['path'])==r['sha256'] for r in sources))
 check('Every original application file unchanged',len(software)==10 and all(sha(ROOT/r['path'])==r['sha256'] for r in software))
 cases=read(ROOT/'parameters/config_index.csv');records=read(ROOT/'parameters/parameter_register.csv');js=json.loads((ROOT/'parameters/parameter_register.json').read_text())
 check('88 unique application configurations',len(cases)==len({(r['scenario'],r['soc_major']) for r in cases})==88)
 check('528 explicitly classified parameter records',len(records)==len(js)==528 and all(r['class'] in ['Observed','Estimate','Assumption'] for r in records))
 check('Parameter CSV/JSON parity',all(all((close(r[k],v) if isinstance(v,(float,int)) else r[k]==v) for k,v in j.items()) for r,j in zip(records,js)))
 for case in cases:
  path=ROOT/case['parameter_file'];p=load_parameters(path);expected,lineage=application_input(bygroup[case['soc_major']],byscenario[case['scenario']],settings)
  check(case['scenario']+'/'+case['soc_major']+' accepts exactly six model fields',set(p)==set(FIELDS) and p==expected and all(type(p[k]) is int for k in ['employees','replaced','years']))
  check(case['scenario']+'/'+case['soc_major']+' count and capacity bounds',0<=p['replaced']<=p['employees'] and p['replaced']<=lineage['spare_capacity_equivalents']+1e-8)
  output=ROOT/'results/annual'/case['scenario']/f"EC426767_{case['scenario']}_SOC{case['soc_major']}.csv";rows=read(output)
  check(case['scenario']+'/'+case['soc_major']+' five original-schema output rows',len(rows)==5 and list(rows[0])==list(RESULT_COLUMNS))
  n=Decimal(p['employees']);r=Decimal(p['replaced']);c=Decimal(str(p['annual_employee_cost']));a=Decimal(str(p['annual_ai_cost']));i=Decimal(str(p['implementation_cost']))
  for year,row in enumerate(rows,1):
   baseline=n*c;cost=(n-r)*c+a+(i if year==1 else 0);saving=r*c-a-(i if year==1 else 0)
   expectedvals=dict(year=year,baseline_cost=baseline,scenario_cost=cost,savings=saving,cumul_baseline=year*baseline,cumul_scenario=year*((n-r)*c+a)+i,cumul_savings=year*(r*c-a)-i)
   for key,v in expectedvals.items():
    ok=close(row[key],v);reconciliations.append(dict(scenario=case['scenario'],soc_major=case['soc_major'],year=year,metric=key,exported_value=row[key],independent_value=str(v),status='PASS' if ok else 'FAIL'))
 check('All 3080 exported application fields reconcile independently',len(reconciliations)==3080 and all(r['status']=='PASS' for r in reconciliations))
 annual=read(ROOT/'results/tables/EC426767_Annual_Results.csv');summary=read(ROOT/'results/tables/EC426767_Scenario_Results.csv');groupresults=read(ROOT/'results/tables/EC426767_Occupational_Results.csv')
 check('Four scenarios,88 group outcomes and20 aggregate years',len(summary)==4 and len(groupresults)==88 and len(annual)==20)
 check('Unchanged baseline employment and annual cost in every scenario',len({r['employees'] for r in summary})==1 and len({r['annual_employee_cost_base_ron'] for r in summary})==1)
 for s in summary:
  gid=s['scenario'];gs=[r for r in groupresults if r['scenario']==gid];ys=[r for r in annual if r['scenario']==gid]
  check(gid+' group and aggregate reconciliation',close(sum(float(r['five_year_savings_ron']) for r in gs),s['five_year_savings_ron']) and sum(int(r['replaced_at_start']) for r in gs)==int(s['replaced_at_start']))
  check(gid+' savings after year1 remain constant',all(close(r['savings'],ys[1]['savings']) for r in ys[1:]))
  check(gid+' setup paid once',close(Decimal(ys[1]['savings'])-Decimal(ys[0]['savings']),s['one_time_implementation_ron']))
 check('S0 control yields zero costs beyond labor and zero savings',all(float(next(r for r in summary if r['scenario']=='S0')[k])==0 for k in ['replaced_at_start','annual_ai_cost_ron','one_time_implementation_ron','five_year_savings_ron']))
 sensitivity=read(ROOT/'results/tables/EC426767_Sensitivity_Results.csv');si=read(ROOT/'parameters/sensitivity_inputs.csv');sd=read(ROOT/'results/tables/EC426767_Sensitivity_Annual_Results.csv')
 check('Eight OAT variables,352 original-model calls,1760 exported sensitivity years',len(sensitivity)==8 and len(si)==352 and len(sd)==1760)
 check('Sensitivity swing arithmetic',all(close(abs(float(r['five_year_savings_A_ron'])-float(r['five_year_savings_B_ron'])),r['absolute_swing_ron']) for r in sensitivity))
 for r in si:
  config={k:int(r[k]) if k in ['employees','replaced','years'] else float(r[k]) for k in FIELDS};projection=run_projection(config);saved=[x for x in sd if x['parameter']==r['parameter'] and x['endpoint']==r['endpoint'] and x['soc_major']==r['soc_major']]
  assert len(saved)==5 and all(close(x['cumul_savings'],y['cumul_savings']) for x,y in zip(saved,projection))
 check('All sensitivity endpoints reproduce via original application function',True)
 tests=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-v'],cwd=APP,capture_output=True,text=True)
 (ROOT/'verification/EC426767_Application_Test_Log.txt').write_text(tests.stdout+tests.stderr,encoding='utf-8')
 check('Seven supplied application tests pass',tests.returncode==0 and 'Ran 7 tests' in tests.stderr)
 from prepare_parameters import write
 write(ROOT/'verification/numeric_reconciliation.csv',reconciliations)
 report=dict(status='PASS',checks_passed=len(checks),application_tests=7,independently_reconciled_fields=len(reconciliations),baseline_configurations=88,baseline_cli_executions=88,sensitivity_cases=352,checks=checks,scope='Original ECorp engine and JSON/CSV workflow; no source-code changes. Scenario inputs and budgets remain exploratory assumptions.')
 (ROOT/'verification/EC426767_Verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
 print(f"PASS: {len(checks)} integration checks; 7 supplied tests; 3080 exported fields reconciled.")
if __name__=='__main__':main()
