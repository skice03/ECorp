"""Prepare six-field application inputs from occupational evidence."""
from pathlib import Path
from collections import defaultdict
from decimal import Decimal,ROUND_HALF_UP,ROUND_FLOOR
import csv,json,math
ROOT=Path(__file__).resolve().parents[1]
FIELDS=['employees','replaced','annual_employee_cost','annual_ai_cost','implementation_cost','years']
def read(path):
 with path.open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def write(path,rows):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def D(value):return Decimal(str(value))
def money(value):return float(D(value).quantize(D('.01'),rounding=ROUND_HALF_UP))
def floor(value):return int(D(value).to_integral_value(rounding=ROUND_FLOOR))
def load():
 settings=json.loads((ROOT/'parameters/settings.json').read_text())
 scenarios=json.loads((ROOT/'parameters/scenario_design.json').read_text())
 rows=read(ROOT/'data/occupations.csv')
 for r in rows:
  for key in ['employment_2022_thousands','wage_2022_usd','human_alpha','human_beta','human_gamma']:
   r[key]=float(r[key]) if r[key] else None
 return settings,scenarios,rows
def aggregate_groups(rows,settings):
 buckets=defaultdict(list)
 for r in rows:buckets[r['soc'][:2]].append(r)
 out=[]
 for code,rs in sorted(buckets.items()):
  emp=math.fsum(r['employment_2022_thousands'] for r in rs);known=[r for r in rs if r['wage_2022_usd'] is not None];known_emp=math.fsum(r['employment_2022_thousands'] for r in known)
  wage=math.fsum(r['employment_2022_thousands']*r['wage_2022_usd'] for r in known)/known_emp
  g=dict(soc_major=code,group=rs[0]['group'],occupations=len(rs),employees=int(round(emp*1000)),wage_covered_employees=int(round(known_emp*1000)),wage_coverage=known_emp/emp,weighted_median_wage_proxy_usd=wage,loaded_employee_cost_usd=wage*settings['benefit_loading'],annual_employee_cost=money(D(wage)*D(settings['benefit_loading'])*D(settings['usd_to_ron'])))
  for key in ['human_alpha','human_beta','human_gamma']:g[key]=math.fsum(r['employment_2022_thousands']*r[key] for r in rs)/emp
  out.append(g)
 return out
def application_input(g,s,settings,annual_ai_factor=1,setup_factor=1):
 N=g['employees'];a=D(s['deployment_share']);e=D(g[s['exposure_measure']]);t=D(s['time_saved']);redeploy=D(s['demand_redeployment'])
 capacity=D(N)*a*e*t*(1-redeploy);target=D(N)*D(s['initial_replacement_share']);R=max(0,min(N,floor(min(capacity,target))))
 users=int((D(N)*a).to_integral_value(rounding=ROUND_HALF_UP));fx=D(settings['usd_to_ron'])
 annual=money(D(users)*D(s['license_usd'])*D(s['integration_multiple'])*fx*D(annual_ai_factor))
 setup_reserve=money(D(users)*D(s['license_usd'])*fx*D(setup_factor));training=money(D(R)*D(s['training_usd'])*fx)
 config=dict(employees=N,replaced=R,annual_employee_cost=g['annual_employee_cost'],annual_ai_cost=annual,implementation_cost=money(D(setup_reserve)+D(training)),years=settings['years'])
 lineage=dict(scenario=s['id'],soc_major=g['soc_major'],group=g['group'],planned_ai_users=users,exposure_measure=s['exposure_measure'],exposure_value=float(e),deployment_share=float(a),time_saved=float(t),demand_redeployment=float(redeploy),initial_replacement_share=s['initial_replacement_share'],spare_capacity_equivalents=float(capacity),initial_replacement_target=float(target),one_time_integration_reserve_ron=setup_reserve,one_time_training_ron=training,annual_ai_cost_ron=annual,replaced=R,rounding_rule='Floor of smaller initial target and spare-capacity bound; AI-user count rounded to nearest integer.')
 return config,lineage
def main():
 settings,scenarios,rows=load();groups=aggregate_groups(rows,settings)
 assert len(rows)==785 and len(groups)==22 and sum(g['employees'] for g in groups)==161931500
 write(ROOT/'parameters/occupational_parameters.csv',groups)
 write(ROOT/'parameters/scenario_design.csv',scenarios)
 records=[];lineages=[];register=[];index=[]
 for s in scenarios:
  for g in groups:
   config,lineage=application_input(g,s,settings);lineages.append(lineage)
   path=ROOT/'ECorp/config/enache'/s['id']/f"EC426767_{s['id']}_SOC{g['soc_major']}.json"
   path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(config,indent=2),encoding='utf-8')
   records.append(dict(scenario=s['id'],soc_major=g['soc_major'],group=g['group'],**config));index.append(dict(scenario=s['id'],soc_major=g['soc_major'],parameter_file=path.relative_to(ROOT).as_posix()))
   descriptions={
    'employees':('Observed','employees','R02','Original 2022 group employment; no workforce rescaling.'),
    'replaced':('Assumption','employees at projection start','Scenario design','Initial integer replacement choice, bounded by derived spare capacity; fixed throughout the projection.'),
    'annual_employee_cost':('Estimate','RON/employee/year','R02; R03; R05','Known-wage weighted occupation median proxy times 1.43 loading and 4.6885 RON/USD; rounded to cents.'),
    'annual_ai_cost':('Assumption','RON/year total','R03; scenario design; R05','Planned AI users times annual license and recurring integration multiple; total cost, not a per-user value.'),
    'implementation_cost':('Assumption','RON total, once in year1','R03; scenario budget; R05','One-time integration reserve plus initial training. Reserve per AI user equals one annual license fee as an explicit exploratory budget assumption.'),
    'years':('Assumption','years','Scenario design','Five-year constant-workforce cost projection.')}
   for key,value in config.items():
    cls,unit,source,meaning=descriptions[key];register.append(dict(scenario=s['id'],soc_major=g['soc_major'],parameter=key,value=value,unit=unit,**{'class':cls},source=source,definition=meaning))
 write(ROOT/'parameters/application_inputs.csv',records);write(ROOT/'parameters/input_derivations.csv',lineages);write(ROOT/'parameters/parameter_register.csv',register);write(ROOT/'parameters/config_index.csv',index)
 (ROOT/'parameters/parameter_register.json').write_text(json.dumps(register,indent=2),encoding='utf-8')
 candidates=[dict(variable=k,definition=v[0],availability=v[1],model_use=v[2]) for k,v in {
 'employees':('Baseline group workforce','Observed 2022 employment, R02','Application input'),
 'replaced':('Employees replaced at projection start','Exploratory initial target bounded by task capacity','Application input; Assumption'),
 'annual_employee_cost':('Annual loaded cost per employee','Derived wage/loading/currency estimate','Application input; Estimate'),
 'annual_ai_cost':('Total recurring AI cost','License proxy and planned AI-user count','Application input; Assumption'),
 'implementation_cost':('Total initial implementation budget','One-time integration reserve plus training','Application input; Assumption'),
 'years':('Projection horizon','Five-year scenario selection','Application input; Assumption'),
 'exposure':('Task exposure alpha/beta/gamma','Task-based ratings, R01/R02','Parameter derivation only'),
 'deployment_share':('Planned AI-user coverage','Scenario assumption','Parameter derivation only'),
 'time_saved':('Savings on exposed task time','Transferred estimate, R03','Parameter derivation only'),
 'demand_redeployment':('Freed capacity allocated to output','Scenario assumption','Parameter derivation only'),
 'training_proxy':('One-time training per replaced worker','General-training proxy, R03','Included within initial implementation budget'),
 'usd_to_ron':('Constant reporting currency factor','2022 annual average 4.6885, R05','Unit conversion; no Romanian wage localization')}.items()]
 write(ROOT/'week1/EC426767_Enache_Week01_Variable_Register.csv',candidates)
 initial=[dict(parameter='Annual labor cost',central=money(math.fsum(g['employees']*g['annual_employee_cost'] for g in groups)/161931500),low=min(g['annual_employee_cost'] for g in groups),high=max(g['annual_employee_cost'] for g in groups),unit='RON/employee/year',**{'class':'Estimate'},basis='Employment-weighted group cost proxy; bounds are group variation, not confidence limits.'),dict(parameter='Task time saved',central=.25,low=.12,high=.4,unit='share of exposed time',**{'class':'Estimate'},basis='R03 transferred task-level range.'),dict(parameter='Annual license',central=money(D(306)*D(settings['usd_to_ron'])),low=money(D(252)*D(settings['usd_to_ron'])),high=money(D(360)*D(settings['usd_to_ron'])),unit='RON/AI user/year',**{'class':'Assumption'},basis='Reported USD band converted to constant RON; proxy, not a quote.'),dict(parameter='Initial replacement target',central=.005,low=.001,high=.01,unit='share of baseline employees, once at start',**{'class':'Assumption'},basis='Exploratory target; bounded by available task capacity and rounded down.'),dict(parameter='Initial training',central=money(D(1050)*D(settings['usd_to_ron'])),low=money(D(846)*D(settings['usd_to_ron'])),high=money(D(1254)*D(settings['usd_to_ron'])),unit='RON/replaced employee once',**{'class':'Assumption'},basis='General-training budget proxy, not AI-specific evidence.')]
 write(ROOT/'week1/EC426767_Enache_Week01_Parameter_Ranges.csv',initial)
 print('Prepared 88 application JSON files, 528 classified parameter records and 22 occupational groups.')
if __name__=='__main__':main()
