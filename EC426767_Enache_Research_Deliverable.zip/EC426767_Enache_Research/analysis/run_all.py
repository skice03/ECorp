"""Reproduce application parameters, ECorp scenario runs and research outputs."""
from pathlib import Path
import argparse,subprocess,sys,shutil
ROOT=Path(__file__).resolve().parents[1]
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--reports',action='store_true',help='Build publication PDFs/SVGs and verify exported figures.');parser.add_argument('--png',action='store_true',help='Render publication PNGs with Poppler; requires --reports.')
 args=parser.parse_args()
 if args.png and not args.reports:parser.error('--png requires --reports')
 poppler=shutil.which('pdftoppm')
 if args.png and not poppler:parser.error('pdftoppm not found. Supplied PNGs can be used without rendering.')
 for name in ['prepare_parameters.py','run_scenarios.py','verify.py']:
  result=subprocess.run([sys.executable,str(ROOT/'analysis'/name)],capture_output=True,text=True,check=True)
  print(name+': PASS')
 if args.reports:
  subprocess.run([sys.executable,str(ROOT/'analysis/build_reports.py')],capture_output=True,check=True)
  if args.png:
   for p in (ROOT/'figures').glob('*.pdf'):
    subprocess.run([poppler,'-singlefile','-scale-to','2200','-png',str(p),str(p.with_suffix(''))],capture_output=True,check=True)
  subprocess.run([sys.executable,str(ROOT/'analysis/verify_publication.py')],check=True)
 print('Application scenarios and research outputs reproduced successfully.')
if __name__=='__main__':main()
