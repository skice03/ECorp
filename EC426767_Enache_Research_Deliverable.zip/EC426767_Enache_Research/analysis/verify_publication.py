from pathlib import Path
import json,csv
from pypdf import PdfReader
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
def main():
 with (ROOT/'results/tables/EC426767_Scenario_Results.csv').open(encoding='utf-8') as f:rows=list(csv.DictReader(f))
 paper=PdfReader(ROOT/'week4/EC426767_Enache_Publication_Tables.pdf');text='\n'.join(pg.extract_text() for pg in paper.pages)
 count=0
 for r in rows:
  for key in ['first_year_savings_ron','later_annual_savings_ron','five_year_savings_ron']:
   value=f'{float(r[key])/1e9:,.3f}';assert value in text,(r['scenario'],key,value);count+=1
  assert f'{int(r["replaced_at_start"]):,}' in text
 docs=list(ROOT.glob('week*/*.pdf'))+[ROOT/'references/EC426767_Source_Register.pdf']
 pages=0
 for path in docs:
  doc=PdfReader(path);pages+=len(doc.pages)
  content='\n'.join(p.extract_text() for p in doc.pages)
  assert 'Enache Ionuț-Alexandru' in content,path
  if path.parent.name!='references':
   assert 'Bancu' not in content,path
   assert not any(word in content.lower() for word in ['modified','revised','adapted','model unavailable','code was not supplied']),path
   assert 'USD billions' not in content and 'USD bn' not in content,path
 assert pages==15,pages
 images=list((ROOT/'figures').glob('*.png'));assert len(images)==4
 for path in images:
  with Image.open(path) as im:assert max(im.size)==2200;im.verify()
 result=dict(status='PASS',published_primary_values_checked=count,pdf_files=len(docs),pdf_pages=pages,figure_sets=4,png_files=4,financial_reporting_currency='RON',source_attribution='Preserved in source register and unchanged reference documents.',change_labels_in_authored_pdfs=False)
 (ROOT/'verification/EC426767_Publication_Verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print('PASS: published result values,15 report pages and4 figure sets verified.')
if __name__=='__main__':main()
