"""Execute the ECorp JSON/CSV application for all occupational scenarios."""
from pathlib import Path
from copy import deepcopy
import csv,json,math,subprocess,sys,hashlib
from prepare_parameters import load,aggregate_groups,application_input,read,write
ROOT=Path(__file__).resolve().parents[1];APP=ROOT/'ECorp'
sys.path.insert(0,str(APP))
from src.week2 import load_parameters,run_projection,export_results,RESULT_COLUMNS
def numeric_rows(path):return [{k:int(v) if k=='year' else float(v) for k,v in r.items()} for r in read(path)]
def summarize(scenario,yearly,replaced,employees,annual_ai,setup):
 first=yearly[0];last=yearly[-1]
 return dict(scenario=scenario,employees=employees,replaced_at_start=replaced,replaced_percent=100*replaced/employees,annual_employee_cost_base_ron=first['baseline_cost'],annual_ai_cost_ron=annual_ai,one_time_implementation_ron=setup,first_year_scenario_cost_ron=first['scenario_cost'],first_year_savings_ron=first['savings'],later_annual_savings_ron=last['savings'],five_year_baseline_cost_ron=last['cumul_baseline'],five_year_scenario_cost_ron=last['cumul_scenario'],five_year_savings_ron=last['cumul_savings'])
def main():
 settings,scenarios,rows=load();groups=aggregate_groups(rows,settings);index=read(ROOT/'parameters/config_index.csv')
 allrows=[];gsummary=[];execution=[]
 for entry in index:
  input_path=ROOT/entry['parameter_file'];output_path=ROOT/'results/annual'/entry['scenario']/f"EC426767_{entry['scenario']}_SOC{entry['soc_major']}.csv";output_path.parent.mkdir(parents=True,exist_ok=True)
  completed=subprocess.run([sys.executable,'-B',str(APP/'src/week2.py'),'--parameters',str(input_path),'--output',str(output_path)],check=True,capture_output=True,text=True)
  config=load_parameters(input_path);yearly=numeric_rows(output_path)
  # The application output is the authoritative result; no independent model generates it.
  allrows.extend(dict(scenario=entry['scenario'],soc_major=entry['soc_major'],**r) for r in yearly)
  gsummary.append(dict(soc_major=entry['soc_major'],group=next(g['group'] for g in groups if g['soc_major']==entry['soc_major']),**summarize(entry['scenario'],yearly,config['replaced'],config['employees'],config['annual_ai_cost'],config['implementation_cost'])))
  execution.append(dict(scenario=entry['scenario'],soc_major=entry['soc_major'],parameter_file=entry['parameter_file'],result_file=output_path.relative_to(ROOT).as_posix(),exit_code=completed.returncode,parameter_sha256=hashlib.sha256(input_path.read_bytes()).hexdigest(),result_sha256=hashlib.sha256(output_path.read_bytes()).hexdigest()))
 annual=[];summary=[]
 for s in scenarios:
  srows=[r for r in allrows if r['scenario']==s['id']];aggregate=[]
  for y in range(1,settings['years']+1):
   selected=[r for r in srows if r['year']==y];record=dict(year=y,**{k:math.fsum(r[k] for r in selected) for k in RESULT_COLUMNS if k!='year'});aggregate.append(record);annual.append(dict(scenario=s['id'],**record))
  sr=[r for r in gsummary if r['scenario']==s['id']]
  summary.append(summarize(s['id'],aggregate,sum(r['replaced_at_start'] for r in sr),sum(r['employees'] for r in sr),math.fsum(r['annual_ai_cost_ron'] for r in sr),math.fsum(r['one_time_implementation_ron'] for r in sr)))
 write(ROOT/'results/tables/EC426767_Annual_Results.csv',annual);write(ROOT/'results/tables/EC426767_Scenario_Results.csv',summary);write(ROOT/'results/tables/EC426767_Occupational_Results.csv',gsummary)
 write(ROOT/'results/tables/EC426767_Application_Results.csv',allrows)
 (ROOT/'verification/application_executions.json').write_text(json.dumps(execution,indent=2),encoding='utf-8')
 # One-at-a-time analyses call the same original project function used by CLI/UI.
 base=next(s for s in scenarios if s['id']=='S2')
 variants=[('Initial replacement target','initial_replacement_share',.001,.01),('Demand redeployment','demand_redeployment',0,1),('Deployment coverage','deployment_share',.1,.6),('Exposed-task time saving','time_saved',.12,.4),('Exposure measure','exposure_measure','human_alpha','human_gamma'),('Annual AI cost multiplier','annual_ai_factor',.75,1.25),('Initial integration reserve multiplier','setup_factor',0,2),('Training per replaced worker, USD','training_usd',846,1254)]
 sensitivity=[];detail=[];input_rows=[]
 for label,key,low,high in variants:
  ends=[]
  for endpoint,value in [('A',low),('B',high)]:
   s=deepcopy(base);aifactor=1;setupfactor=1
   if key=='annual_ai_factor':aifactor=value
   elif key=='setup_factor':setupfactor=value
   else:s[key]=value
   five=[];yone=[];r_total=0
   for g in groups:
    config,lineage=application_input(g,s,settings,aifactor,setupfactor);projection=run_projection(config)
    r_total+=config['replaced'];five.append(projection[-1]['cumul_savings']);yone.append(projection[0]['savings'])
    input_rows.append(dict(parameter=key,endpoint=endpoint,soc_major=g['soc_major'],**config))
    detail.extend(dict(parameter=key,endpoint=endpoint,soc_major=g['soc_major'],**r) for r in projection)
   ends.append(dict(replaced=r_total,first=math.fsum(yone),five=math.fsum(five)))
  sensitivity.append(dict(parameter=label,key=key,setting_A=low,setting_B=high,replaced_A=ends[0]['replaced'],replaced_B=ends[1]['replaced'],first_year_savings_A_ron=ends[0]['first'],first_year_savings_B_ron=ends[1]['first'],five_year_savings_A_ron=ends[0]['five'],five_year_savings_B_ron=ends[1]['five'],absolute_swing_ron=abs(ends[1]['five']-ends[0]['five'])))
 sensitivity.sort(key=lambda r:-r['absolute_swing_ron'])
 write(ROOT/'results/tables/EC426767_Sensitivity_Results.csv',sensitivity);write(ROOT/'results/tables/EC426767_Sensitivity_Annual_Results.csv',detail);write(ROOT/'parameters/sensitivity_inputs.csv',input_rows)
 runinfo=dict(application='ECorp/src/week2.py -> src.prototype.project_costs',baseline_cli_executions=len(execution),baseline_exported_annual_rows=len(allrows),scenario_count=len(scenarios),occupational_groups=len(groups),sensitivity_function_executions=len(input_rows),sensitivity_annual_rows=len(detail),currency='RON',years=settings['years'],population_employees=sum(g['employees'] for g in groups),random_seed=None,model='Fixed replacement at projection start; one-time implementation in year1; constant recurring costs.')
 (ROOT/'verification/execution_summary.json').write_text(json.dumps(runinfo,indent=2),encoding='utf-8')
 print(json.dumps(runinfo,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
